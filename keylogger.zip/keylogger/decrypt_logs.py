from cryptography.fernet import Fernet

# Load the key
with open("key.key", "rb") as key_file:
    key = key_file.read()

fernet = Fernet(key)

# Decrypt log entries
with open("logs/encrypted_log.txt", "rb") as log_file:
    for line in log_file:
        line = line.strip()
        if line:
            try:
                decrypted = fernet.decrypt(line).decode()
                print(decrypted)
            except Exception as e:
                print("[Failed to decrypt line]", e)